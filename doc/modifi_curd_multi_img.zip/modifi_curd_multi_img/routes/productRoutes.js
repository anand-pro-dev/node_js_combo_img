import express from 'express';
const router = express.Router();

import Product from "../model/productModel.js";
import upload from "../middleware/uploads.js";

import {
    product_all,
    product_create,
    product_details,
    product_update,
    product_delete,
    product_delete_all
} from '../Controller/productController.js';

router.get('/', product_all);
router.get('/:id', product_details);

// router.post('/', product_create);


// Route to create a new product with multiple images
router.post('/product', upload, async (req, res) => {
    try {
        const { title, price, details } = req.body;
        const images = req.files.map(file => ({
            imageUrl: `${req.protocol}://${req.get('host')}/uploads/${file.filename}`
        }));

        let errorMessage = '';
        if (!title) errorMessage += 'Name is required. ';

        // Add more validation if needed

        if (errorMessage) {
            return res.status(400).json({ status: false, message: errorMessage.trim() });
        }

        const product = new Product({ title, price, images, details });
        const savedProduct = await product.save();
        res.json({ status: true, data: savedProduct });

    } catch (error) {
        res.status(400).json({ status: false, error: error.message });
    }
})


router.put('/:id', product_update);

router.delete('/:id', product_delete);

router.delete('/all/delete', product_delete_all);

export default router;